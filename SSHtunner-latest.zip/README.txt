SSHtunner No-login v2.5
Built on open source Private SSH Manager (YoloTeam - https://yoloteam.org/)

;You need run \ProxifierPE\ProxifierPE\Proxifier.exe - I have config fake ip on Firefox, if you want fake ip on other browsers, please addon it at Proxifier

;Run SSHtunner No-login.exe and login with your username and password

;If you want check update run SSHtunner Update Launcher.exe or Help\Check update

Official site: www.no-login.com
